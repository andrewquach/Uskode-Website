<div class="widget">
<h3>Flickr Stream</h3>
<?php $flickr = get_option('swt_flickr_code6');  echo stripslashes($flickr); ?>
</div>
