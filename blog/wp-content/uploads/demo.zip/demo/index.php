<?php get_header(); ?>
<section id="contentcontainer"> <!-- HTML5 section tag for the content 'section' -->
    
    	<div id="banner"><?php if (get_option('swt_slider') == 'Hide') { ?>
<?php { echo ''; } ?>
<?php } else { include(TEMPLATEPATH . '/includes/slide.php'); } ?></div>
        
    	<div id="home-latestproject">
        	<article><!-- HTML5 article tag -->
            	<img src="<?php bloginfo('template_directory'); ?>/images/latestproject.jpg" alt="Latest Project" width="353" height="151">
           		<h1>Latest Project</h1>
           		<em><span class="blue-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</span></em>
            	<p>Curabitur vitae ante sapien, ultricies luctus turpis. Etiam in risus vestibulum velit interdum malesuada a eu tellus. Quisque vehicula, augue et tristique rutrum, erat dolor scelerisque nisi, vel blandit est risus at mauris. Curabitur aliquam tristique velit eu vestibulum. Mauris consequat, elit a iaculis facilisis, quam quam elementum mauris, id aliquet urna erat pharetra risus. Quisque tincidunt massa sed tortor ultricies ut auctor felis auctor.</p>
                <a href="#" class="link" title="Read More"><strong>Read More</strong></a>
            	<div class="clr"></div>
          </article>
        </div>
        
        <div id="home-threeboxes">
        
        	<div class="home-box">
        	  <div class="ser-1">
        	    <h1><span class="blue-text">Advanced</span><br />Web Development</h1>
                <p>Vivamus rutrum, velit eu sodales sagittis, massa dolor pretium nunc, id ultrices velit elit adipiscing nulla. Quisque metus nibh, eleifend congue tincidunt non, pretium eu nunc. In malesuada ante non tellus laoreet consequat. Quisque volutpat arcu ante, a posuere elit. Aenean non mattis purus.</p>
                <a href="#" class="link" title="Read More"><strong>Read More</strong></a>
        	  </div>
        	</div>
            
        	<div class="home-box">
        	  <div class="ser-2">
        	    <h1><span class="blue-text">Business</span><br />Application Development</h1>
                <p>Vivamus rutrum, velit eu sodales sagittis, massa dolor pretium nunc, id ultrices velit elit adipiscing nulla. Quisque metus nibh, eleifend congue tincidunt non, pretium eu nunc. In malesuada ante non tellus laoreet consequat. Quisque volutpat arcu ante, a posuere elit. Aenean non mattis purus.</p>
                <a href="#" class="link" title="Read More"><strong>Read More</strong></a>
        	  </div>
        	</div>
            
   	    <div class="home-box">
        	  <div class="ser-3">
        	    <h1><span class="blue-text">Driving the world of</span><br />E-Commerce</h1>
                <p>Vivamus rutrum, velit eu sodales sagittis, massa dolor pretium nunc, id ultrices velit elit adipiscing nulla. Quisque metus nibh, eleifend congue tincidunt non, pretium eu nunc. In malesuada ante non tellus laoreet consequat. Quisque volutpat arcu ante, a posuere elit. Aenean non mattis purus.</p>
                <a href="#" class="link" title="Read More"><strong>Read More</strong></a>
       	  </div>
       	  </div>
          <div class="clr"></div>
   	    </div>
        
      <div id="home-socialmedia">
      	<div class="home-box">
        	<iframe src="http://www.facebook.com/plugins/activity.php?site=https%3A%2F%2Fwww.facebook.com%2Fpreviousdesign&amp;width=280&amp;height=200&amp;header=false&amp;colorscheme=light&amp;font&amp;border_color&amp;recommendations=false" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:280px; height:200px;" allowTransparency="true"></iframe>
        </div> 
        <div class="home-box">
        	<script src="http://widgets.twimg.com/j/2/widget.js"></script>
<script>
new TWTR.Widget({
  version: 2,
  type: 'search',
  search: 'rainbow',
  interval: 6000,
  title: 'USKODE.COM',
  subject: 'Across the sky',
  width: 'auto',
  height: 150,
  theme: {
    shell: {
      background: '#8ec1da',
      color: '#ffffff'
    },
    tweets: {
      background: '#ffffff',
      color: '#444444',
      links: '#1985b5'
    }
  },
  features: {
    scrollbar: false,
    loop: true,
    live: true,
    hashtags: false,
    timestamp: true,
    avatars: true,
    toptweets: false,
    behavior: 'default'
  }
}).render().start();
</script>
        </div>
        <div class="home-box">
        	<div class="home-testi">
           	  <h1>Testimonials</h1>
                <p>&quot;Vivamus rutrum, velit eu sodales sagittis, massa dolor pretium nunc, id ultrices velit elit adipiscing nulla. Quisque metus nibh, eleifend congue tincidunt non, pretium eu nunc.&quot;<br>
                  <br>
                  - Darpan Patel<br>
                <em><span class="blue-text">Previous Design</span></em></p>
                <a href="#" class="link" title="View More"><strong>View More</strong></a>
            
            </div>
        </div>
        <div class="clr"></div>
      </div>
        
      <div class="ser-logos">
      	<img src="<?php bloginfo('template_directory'); ?>/images/logos/hadoop.gif" />
        <img src="<?php bloginfo('template_directory'); ?>/images/logos/hadoop.gif" />
        <img src="<?php bloginfo('template_directory'); ?>/images/logos/hadoop.gif" />
        <img src="<?php bloginfo('template_directory'); ?>/images/logos/hadoop.gif" />
        <img src="<?php bloginfo('template_directory'); ?>/images/logos/hadoop.gif" />
        <img src="<?php bloginfo('template_directory'); ?>/images/logos/hadoop.gif" />
        <img src="<?php bloginfo('template_directory'); ?>/images/logos/hadoop.gif" />
        <img src="<?php bloginfo('template_directory'); ?>/images/logos/hadoop.gif" />
	  </div>
      
    </section>


<?php include('sidebar-bottom.php'); ?>
<?php get_footer(); ?>
