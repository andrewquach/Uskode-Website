<footer>

      <div class="services-box">
      <?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar(2) ) : else : ?>
        <h1>Services</h1>
        <ul>
          <?php wp_list_bookmarks('title_li=&categorize=0');  ?>
        </ul>
        <?php endif; ?>
      </div>
      
      <div class="sitemap-box">
      <?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar(3) ) : else : ?>
        <div class="widget">
    <h3>Text Widget</h3>
    </div>
        <?php endif; ?>
      </div>
      
      <div class="contactus-box">
        
<?php if (get_option('swt_flickr') == 'Hide') { ?>
<?php { echo ''; } ?>
<?php } else { include(TEMPLATEPATH . '/includes/flickr.php'); } ?>

<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar(4) ) : else : ?>

<?php endif; ?>
      </div>
      
      <div class="stay-box">
       
<?php if (get_option('swt_twidget') == 'Hide') { ?>
<?php { echo '<div id="shiftdown"></div>'; } ?>
<?php } else { include(TEMPLATEPATH . '/includes/twitter.php'); } ?>

<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar(5) ) : else : ?>

<?php endif; ?>
      </div>
      
    </footer>
<div id="sidebar-wrap">
<div id="sidebar2">

</div>
