<div class="side-widget">
<h3>Our Sponsors</h3>
      <a href="<?php $link1 = get_option('swt_link1'); echo $link1; ?>"><img src="<?php $banner1 = get_option('swt_banner1kastol'); echo $banner1; ?>" class="add1" alt="advertisement" /></a>
      <a href="<?php $link2 = get_option('swt_link2'); echo $link2; ?>"><img src="<?php $banner2 = get_option('swt_banner2kastol'); echo $banner2; ?>" class="add2" alt="advertisement" /></a>
      <a href="<?php $link3 = get_option('swt_link3'); echo $link3; ?>"><img src="<?php $banner3 = get_option('swt_banner3kastol'); echo $banner3; ?>" class="add1" alt="advertisement" /></a>
      <a href="<?php $link4 = get_option('swt_link4'); echo $link4; ?>"><img src="<?php $banner4 = get_option('swt_banner4kastol'); echo $banner4; ?>" class="add2" alt="advertisement" /></a>
</div>