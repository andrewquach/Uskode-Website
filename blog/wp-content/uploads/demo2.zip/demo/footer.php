<div class="copyright">&copy; 2011 Uskode Solution - All rights reserved.

<!-- Please do not edit following code, it may cause your site to stop working!
<div class="alignleft">Copyright &copy; <?php echo date('Y'); ?>. All Rights Reserved. <a href="http://www.mywpthemesite.com/theme/kastolinomag">Kastolino Mag</a> <a href="http://www.mywpthemesite.com">Free Wordpress Theme</a> by <a href="http://www.dreamhostreviewme.com">Dreamhost Reviews</a></div> -->

</div>
<?php
 $code = get_option('swt_custom_analytics_code'); echo stripslashes($code);
?>
<?php wp_footer();?>
</body>
</html>